import SwiftUI

struct AboutMe: View {
    var body: some View {
        
        NavigationStack {
            ZStack { 
                Color.black
                
                VStack{
                    
                    Image ("AboutMe")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 920, height: 920)
                    Spacer ()
                    
                }
            }
        }
    }
}
