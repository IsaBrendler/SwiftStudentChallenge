import ARKit
import SwiftUI
import RealityKit
import PlaygroundSupport

/// You can use this class to load an AR experience from a reality file and create anchor entities for it.
class ARExperience: RealityKit.Entity, RealityKit.HasAnchoring {
    
    static func load(named resourceName: String) -> ARExperience {
        if let url = Bundle.main.url(forResource: resourceName, withExtension: "reality") {
            let anchor = try! ARExperience.loadAnchor(contentsOf: url)
            return ARExperience(anchor: anchor)
        }
        return ARExperience()
    }
    
    required init() {
        super.init()
    }
    
    required init(anchor: RealityKit.AnchorEntity) {
        super.init()
        self.anchoring = anchor.anchoring
        self.addChild(anchor)
    }
    
}

struct ARViewContainer: UIViewRepresentable {
    
    func makeUIView(context: Context) -> ARView {
        
        let arView = ARView(frame: .zero, cameraMode: .ar, automaticallyConfigureSession: true)        
        
        let experience = ARExperience.load(named: "Project9")
        
  
        arView.scene.addAnchor(experience)
    
        return arView
        
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {
        
    }
}


struct Onboarding: View {
    
    @State var isLoading = false
    
    @State var shouldNavigate = false
    
    
    var body: some View {
        NavigationStack{
            
            ZStack{
                Spacer ()
                Color.black
                VStack{
                    
                    HStack{
                        
                        Image("onboarding")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 780, height: 780)}
                        
                 
                    }
                    
                    VStack{   
                        
                        ProgressView()
                            .opacity(isLoading ? 1 : 0)
                        .padding(250)
                        Button{
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                shouldNavigate = true                                
                            }
                            isLoading = true
                        } label: {
                            Text("Start AR Experience")
                                .font(.custom("SF Pro Rounded", size: 24))
                                .frame(width: 220, height: 40)
                                .cornerRadius(16)
                                .fontWeight(.semibold)
                                .padding()
                                .foregroundColor(.white)
                                .background(Color.brandPurple)
                                .cornerRadius(16)
                              
                        }
                       
                        .navigationDestination(isPresented: $shouldNavigate) {
                            ARViewContainer()
                                .edgesIgnoringSafeArea(.all)
                                .onAppear {
                                    isLoading = false
                                }
                        }
                    }
                }
            }
            Spacer()
            Spacer ()
        
    }
}
