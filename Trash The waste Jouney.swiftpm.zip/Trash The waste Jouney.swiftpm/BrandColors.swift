import Foundation
import SwiftUI

extension Color {
    //brand colors
    public static let brandPurple: Color = Color(red: 124/255, green: 122/255, blue: 255/255) 
    public static let brandBlue: Color = Color(red: 59/255, green: 58/255, blue: 137/255)
    
    
}
