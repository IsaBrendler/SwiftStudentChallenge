import ARKit
import SwiftUI
import RealityKit
import PlaygroundSupport


struct ContentView: View {
    
    var body: some View {
        NavigationStack {
            ZStack { 
                Color.black
                
                VStack {
                    Spacer()
                    Image("logoComSlogan")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 650, height: 650)
                    
                    
                    
                    HStack {
                        
                        NavigationLink(destination: AboutMe()) {
                            Text("About Me")
                                .font(.custom("SF Pro Rounded", size: 24))
                                .frame(width: 200, height: 50)
                                .cornerRadius(16)
                                .fontWeight(.semibold)
                                .padding()
                                .foregroundColor(.white)
                                .background(Color.brandBlue)
                                .cornerRadius(16)
                        }
                        .padding(40)
                        
                        NavigationLink(destination: Onboarding()) {
                            
                            Text("Play")
                                .font(.custom("SF Pro Rounded", size: 24))
                                .frame(width: 200, height: 50)
                                .cornerRadius(16)
                                .fontWeight(.semibold)
                                .padding()
                                .foregroundColor(.white)
                                .background(Color.brandPurple)
                                .cornerRadius(16)
                        }
                    }
                    Spacer()
                }
                .padding(.all)
            }
        }
    }
}
